# Ringtone File

To enable the iPhone ringtone feature, please add an MP3 file named `tone.mp3` in this directory.

You can:
1. Download an iPhone ringtone from the internet
2. Use any MP3 file you prefer
3. Or use a browser default sound if the file is not found

The file should be named exactly: `tone.mp3`

For testing purposes, you can use any MP3 file or create a simple beep sound. 